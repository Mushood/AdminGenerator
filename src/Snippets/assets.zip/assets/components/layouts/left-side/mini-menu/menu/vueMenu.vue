<template>
    <div class="vuemenu">
        <slot></slot>
    </div>
</template>
