<template>
    <div>
        <div class="row">
            <div class="col-lg-12 mb-3">
                <b-card header="All categories" header-tag="h4" class="bg-info-card">
                    <div class="pull-right" id="action_row">
                        <button class="btn btn-success" @click='addCat'>
                            Add New
                        </button>
                    </div>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Description</th>
                                <th scope="col">Image</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(category,index) in categories" v-if="!category.edit">
                                <th scope="row">{{ index+1 }}</th>
                                <td>{{ category.name }}</td>
                                <td>{{ category.body }}</td>
                                <td>
                                    <img :src='category.file' alt='image' class='category_image' />
                                </td>
                                <td>
                                    <i class='fa fa-pencil text-info mr-3' @click='editCat(category)'></i>
                                    <i class='fa fa-trash text-danger' @click='deleteCat(category)'></i>
                                </td>
                            </tr>

                            <tr v-else>
                                <th scope="row">{{ index+1 }}</th>
                                <td>
                                    <input type="text" :class="{ 'form-control': true, 'form-danger': errors.first('name') }" v-model="category.name" name="name" v-validate="'required'" />
                                    <span v-show="errors.has('name')" class="help is-danger">{{ errors.first('name') }}</span>
                                </td>
                                <td>
                                    <input type="text" class="form-control" v-model="category.body" />
                                </td>
                                <td>
                                    <img :src='category.selected_media.src' alt='image' class='category_image' v-if="category.selected_media != undefined" />
                                    <img :src='category.file' alt='image' class='category_image' v-else-if="!category.new" />
                                    <i
                                        class='fa fa-plus text-info mr-3'
                                        v-b-modal.media_selection variant="outline-secondary"
                                        @click="notifyCategory(index)"
                                    ></i>
                                    <br />
                                    <input type="hidden" :value="hasMedia(category)" name="file" v-validate="'required'" />
                                    <span v-show="errors.has('file')" class="help is-danger">{{ errors.first('file') }}</span>
                                </td>
                                <td v-if="category.new">
                                    <i class='fa fa-check text-info mr-3' @click='sendNewCat(category, index)'></i>
                                    <i class='fa fa-trash text-danger' @click='removeCat(index)'></i>
                                </td>
                                <td v-else>
                                    <i class='fa fa-times text-info mr-3' @click='restoreCat(category)'></i>
                                    <i class='fa fa-check text-info mr-3' @click='updateCat(category, index)'></i>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <b-pagination
                            size="md"
                            :total-rows="paginator.total"
                            v-model="paginator.current_page"
                            :per-page="paginator.per_page"
                            v-on:change="reloadCategories"
                            align="center"
                    > </b-pagination>
                </b-card>
            </div>
        </div>
        <media_selection></media_selection>
    </div>
</template>
<script>
    import Vue from 'vue';
    import swal from 'sweetalert2';
    import {
        ClientTable,
        Event
    } from 'vue-tables-2';
    import datatable from "components/plugins/DataTable/DataTable.vue";
    import VModal from 'vue-js-modal';
    import miniToastr from 'mini-toastr';
    import VeeValidate from 'vee-validate';

    miniToastr.init();
    Vue.use(ClientTable, {}, false);
    Vue.use(VModal);
    Vue.use(VeeValidate);
    Vue.component('media_selection', require('./../gallery/selection.vue'));

    export default {
        name: "advanced_tables",
        components: {
            datatable
        },
        data() {
            return {
                categories: [],
                selected_media: {
                    name: undefined,
                    src: undefined
                },
                list: [],
                paginator: {
                    current_page: 1,
                    per_page: 0,
                    total: 0,
                },
            }
        },
        methods: {
            getCategories() {
                const vm = this;
                axios.get(
                    this.$store.state.url + "/api/admin/category?page="+vm.paginator.current_page,
                    { 'headers': { 'Authorization': "Bearer " + vm.$store.state.user.token } }
                ).then(response => {
                    vm.categories = vm.setup(response.data.data);
                    vm.paginator  = response.data.meta.pagination;
                })
                .catch(function(error) {
                    miniToastr.error(error.message, "Failure")
                });
            },

            reloadCategories(e) {
                const vm = this;
                vm.paginator.current_page = e;
                vm.getCategories();
            },

            setup(categories) {
                for (var i = 0; i < categories.length; i++) {
                    categories[i].edit = false;
                    categories[i].new = false;
                    categories[i].selected_media = undefined;
                }

                return categories;
            },

            editCat(category) {
                category.temp_name = category.name;
                category.temp_file = category.file;
                category.temp_body = category.body;

                category.edit = true;
            },

            addCat() {
                if(this.checkIfCanAddNew()) {
                    this.categories.unshift({
                        name: "",
                        description: "",
                        file: "",
                        file_slug: "",
                        edit: true,
                        new: true,
                        selected_media: undefined,
                    });
                } else {
                    miniToastr.warn("Please complete the current operation first", "Warning");
                }
            },

            checkIfCanAddNew() {
                let canAdd = true;

                if(this.categories) {
                    for(let index = 0; index < this.categories.length; index++) {
                        if(!this.categories[index]['slug'] ) {
                            canAdd = false;
                        }
                    }
                }

                return canAdd;
            },

            hasMedia(category) {
                if (category.selected_media) {
                    return category.selected_media;
                }

                if (category.file) {
                    return category.file;
                }

                return undefined;
            },

            restoreCat(category) {
                category.name = category.temp_name;
                category.file = category.temp_file;
                category.body = category.temp_body;

                category.edit = false;
                category.selected_media = undefined;
            },

            removeCat(index) {
                this.categories.splice(index, 1);
            },

            sendNewCat(category, index) {
                const vm = this;
                if (category.selected_media) {
                    category.file = category.selected_media.slug;
                }
                this.$validator.validateAll().then((result) => {
                    if (result) {
                        axios.post(
                            this.$store.state.url + "/api/admin/category",
                            {
                                category: category
                            },
                            {
                                'headers': { 'Authorization': "Bearer " + vm.$store.state.user.token }
                            }
                        ).then(response => {
                            vm.categories.splice(index, 1);
                            vm.categories.splice(index,0, {
                                name: response.data.data['name'],
                                body: response.data.data['body'],
                                file: response.data.data['file'],
                                slug: response.data.data['slug'],
                                file_slug: response.data.data['file_slug'],
                                selected_media: undefined,
                                edit: false,
                                new: false,
                            });
                            miniToastr.success("Operation Complete", "Success")
                        })
                        .catch(function(error) {
                            miniToastr.error(error.message, "Failure")
                        });
                    } else {
                        miniToastr.error("Please check form values", "Failure")
                    }
                });
            },

            updateCat(category, index) {
                const vm = this;
                this.$validator.validateAll().then((result) => {
                    if (result) {
                        if (category.selected_media) {
                            category.file = category.selected_media.slug;
                        } else {
                            category.file = category.file_slug;
                        }
                        
                        axios.put(
                            this.$store.state.url + "/api/admin/category/" + category.slug ,
                            {
                            category: category
                            },
                            {
                                'headers': { 'Authorization': "Bearer " + vm.$store.state.user.token }
                            }
                        ).then(response => {
                            vm.categories.splice(index, 1);
                            vm.categories.splice(index,0, {
                                name: response.data.data['name'],
                                body: response.data.data['body'],
                                file: response.data.data['file'],
                                slug: response.data.data['slug'],
                                file_slug: response.data.data['file_slug'],
                                selected_media: undefined,
                                edit: false,
                                new: false,
                            });
                            miniToastr.success("Operation Complete", "Success")
                        })
                        .catch(function(error) {
                            miniToastr.error(error.message, "Failure")
                        });
                    } else {
                        miniToastr.error("Please check form values", "Failure")
                    }
                });
            },

            deleteCat: function(category) {
                const vm = this;

                swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'No, cancel!',
                    reverseButtons: true
                }).then((result) => {
                    if (result.value) {
                        axios.delete(
                            this.$store.state.url + "/api/admin/category/" + category.slug,
                            { 'headers': { 'Authorization': "Bearer " + vm.$store.state.user.token } }
                        ).then(response => {
                            this.getCategories();
                            miniToastr.warn("Operation Complete", "Success")
                        })
                        .catch(function(error) {
                            miniToastr.error(error.message, "Failure")
                        });
                    }
                });
            },

            notifyCategory: function(index) {
                Event.$emit('media_selection_start',{
                    index: index,
                });
            },

            setMedia: function(event) {
                var index = event.index;
                this.categories[index].selected_media = {
                    name: event.name,
                    slug: event.slug,
                    src:  event.src,
                };
            },
        },
        mounted() {
            const vm = this;
            vm.getCategories();
            Event.$on('media_selection_done', function(event){
                vm.setMedia(event);
            });
        }
    }
</script>
<style>
    .category_image{
        max-width: 100px;
    }

    .fa{
        cursor: pointer;
    }

    #action_row{
        margin-bottom: 15px;
    }

    .category_media a p{
        margin-bottom: 1px;
        text-align: center;
    }

    .form-danger {
        border: 1px red solid;
    }

    .is-danger {
        color: red;
    }

    .help {
        padding: 10px;
    }
</style>