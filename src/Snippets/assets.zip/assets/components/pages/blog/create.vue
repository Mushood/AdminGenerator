<template>
    <div class="row">
        <div class="col-lg-12">
            <b-card header="Write new article" header-tag="h4" class="bg-primary-card">
                <form @submit.prevent="submitBlog">
                    <div class="row">
                        <div class="col-sm-12">
                            <a href="#/blog" class="btn btn-primary">
                                Back
                            </a>
                            <div class="pull-right" id="action_row">
                                <button class="btn btn-info" @click='resetBlog' v-if="edit">
                                    <i class="fa fa-retweet"></i>
                                </button>
                                <button class="btn btn-success" type="submit">
                                    <span v-if="edit">Update</span>
                                    <span v-if="!edit">Save</span>
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="row_input">
                                <label for="locale" class="control-label">Language:</label>
                                <select id="locale" class="form-control" v-model="blog.locale" :disabled="!edit" @change="getTranslatedIfExists">
                                    <option value="en">English</option>
                                    <option value="fr">French</option>
                                </select>
                            </div>
                            <div class="row_input">
                                <label for="title" class="control-label">Text:</label>
                                <input id="title" type="text" :class="{ 'form-control': true, 'form-danger': errors.first('title') }" placeholder="title" v-model="blog.name" name="title" v-validate="'required'" />
                                <span v-show="errors.has('title')" class="help is-danger">{{ errors.first('title') }}</span>
                            </div>
                            <div class="row_input">
                                <label for="category" class="control-label">Category:</label>
                                <select id="category" :class="{ 'form-control': true, 'form-danger': errors.first('category') }" v-model="blog.category" name="category" v-validate="'required'">
                                    <option :value="category.slug" v-for="category in categories">{{ category.name }}</option>
                                </select>
                                <span v-show="errors.has('category')" class="help is-danger">{{ errors.first('category') }}</span>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <label for="title" class="control-label">Article Image:</label>
                            <div class="row">
                                <div class="col-sm-6" v-if="blog.file">
                                    <img :src='blog.file' alt='image' class='img-fluid' />
                                </div>
                                <div class="col-sm-6 text-center">
                                    <i
                                            class='fa fa-plus text-info mr-3'
                                            v-b-modal.media_selection variant="outline-secondary"
                                            @click="notifyCategory(0)"
                                    ></i>
                                    <br />
                                    <input type="hidden" :value="hasMedia(blog)" name="file" v-validate="'required'" />
                                    <span v-show="errors.has('file')" class="help is-danger">{{ errors.first('file') }}</span>
                                </div>
                            </div>

                            <media_selection></media_selection>
                        </div>
                    </div>

                    <div class="row_input">
                        <label for="content" class="control-label">Article:</label>
                        <quill-editor
                                :content="blog.body"
                                :options="quilleditorOption"
                                ref="myTextEditor"
                                @change="onEditorChange($event)"
                                class="edi"
                                v-model="blog.body"
                                id="content"
                        ></quill-editor>
                        <input type="hidden" :value="blog.body" name="body" v-validate="'required'" />
                        <span v-show="errors.has('body')" class="help is-danger">{{ errors.first('body') }}</span>
                    </div>
                </form>
            </b-card>
        </div>
    </div>
</template>
<script>
    import Vue from 'vue';
    import VueQuillEditor from 'vue-quill-editor';
    Vue.component('media_selection', require('./../gallery/selection.vue'));
    import {
        Event
    } from 'vue-tables-2';
    import 'codemirror/keymap/sublime';
    import 'codemirror/mode/javascript/javascript.js'
    import miniToastr from 'mini-toastr';
    miniToastr.init();

    // require styles
    import 'quill/dist/quill.core.css'
    import 'quill/dist/quill.snow.css'
    import 'quill/dist/quill.bubble.css'

    Vue.use(VueQuillEditor);

    import VeeValidate from 'vee-validate';
    Vue.use(VeeValidate);

    export default {
        name: "create-blog",
        data() {
            return {
                blog: {
                    name: undefined,
                    body: undefined,
                    file: undefined,
                    category: undefined,
                    file_slug: undefined,
                    locale: 'en',
                },
                original: {
                    name: undefined,
                    body: undefined,
                    file: undefined,
                    category: undefined,
                    file_slug: undefined,
                    locale: undefined,
                },
                temp_blog: {
                    loaded: false,
                    file: undefined,
                    category: undefined,
                    file_slug: undefined,
                },
                upload: false,
                edit: false,
                list: [],
                code: 'const a = 10',
                categories: [],
                quilleditorOption: {
                    modules: {
                        toolbar: [['bold', 'italic', 'underline', 'strike',
                            { 'list': 'ordered'},
                            { 'list': 'bullet' },
                            { 'header': [1, 2, 3, 4, 5, 6, false] },
                            { 'color': ['#d3bc6c'] },
                            { 'align': [] },
                        ],
                            ['link']]
                    },
                },
                editorOptions: {
                    // codemirror options
                    tabSize: 4,
                    mode: 'text/javascript',
                    theme: 'monokai',
                    lineNumbers: true,
                    line: true,
                    keyMap: "sublime",
                    extraKeys: {
                        "Ctrl": "autocomplete"
                    },
                    foldGutter: true,
                    gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
                    styleSelectedText: true,
                    highlightSelectionMatches: {
                        showToken: /\w/,
                        annotateScrollbar: true
                    }
                },
            }
        },
        methods: {
            onEditorChange({
                               editor,
                               html,
                               text
                           }) {
                this.blog.body = html
            },

            notifyCategory: function(index) {
                Event.$emit('media_selection_start',{
                    index: index,
                });
            },

            setMedia: function(event) {
                this.blog.file = event.src;
                this.blog.file_slug = event.slug;
            },

            hasMedia(blog) {
                if (blog.selected_media) {
                    return blog.selected_media;
                }

                if (blog.file) {
                    return blog.file;
                }

                return undefined;
            },

            submitBlog: function () {
                const vm = this;
                this.$validator.validateAll().then((result) => {
                    if (result) {
                        if (vm.edit) {
                            axios.put(
                                this.$store.state.url + "/api/admin/blog/" + vm.blog.slug,
                                {
                                    blog: vm.blog,
                                    language: vm.blog.locale
                                },
                                {
                                    'headers': { 'Authorization': "Bearer " + vm.$store.state.user.token }
                                }
                            ).then(response => {
                                miniToastr.success("Operation Complete", "Success")
                                this.$router.push("/blog");
                            })
                            .catch(function(error) {
                                miniToastr.error(error.message, "Failure")
                            });
                        }

                        if (!vm.edit) {
                            axios.post(
                                this.$store.state.url + "/api/admin/blog", {
                                    blog: vm.blog
                                },
                                {
                                    'headers': { 'Authorization': "Bearer " + vm.$store.state.user.token }
                                }
                            ).then(response => {
                                miniToastr.success("Operation Complete", "Success")
                                this.$router.push("/blog");
                            })
                                .catch(function(error) {
                                    miniToastr.error(error.message, "Failure")
                                });
                        }
                    } else {
                        miniToastr.error("Please check form values", "Failure")
                    }
                });


            },

            loadBlog(slug, locale = 'en') {
                const vm = this;
                axios.get(
                    this.$store.state.url + "/api/admin/blog/" + slug + "/" + locale,
                    { 'headers': { 'Authorization': "Bearer " + vm.$store.state.user.token } }
                ).then(response => {
                    if (response.data.meta.type == "success") {
                        vm.blog = response.data.data;
                        vm.original.file        = response.data.data.file;
                        vm.original.name        = response.data.data.name;
                        vm.original.body        = response.data.data.body;
                        vm.original.category    = response.data.data.category;
                        vm.original.file_slug   = response.data.data.file_slug;
                        vm.original.locale      = response.data.data.locale;

                        if(vm.temp_blog.loaded) {
                            vm.loadTempInfo();
                        }
                    }

                    if (response.data.meta.type == "translation") {
                        vm.blog.name = undefined;
                        vm.blog.body = undefined;
                    }

                })
                .catch(function(error) {
                    miniToastr.error(error.message, "Failure")
                });
            },

            resetBlog() {
                this.blog.file      = this.original.file;
                this.blog.name      = this.original.name;
                this.blog.body      = this.original.body;
                this.blog.category  = this.original.category;
                this.blog.file_slug = this.original.file_slug;
                this.blog.locale    = this.original.locale;
            },

            getCategories() {
                const vm = this;
                axios.get(
                    this.$store.state.url + "/api/admin/category",
                    { 'headers': { 'Authorization': "Bearer " + vm.$store.state.user.token } }
                ).then(response => {
                    vm.categories = response.data.data;
                })
                .catch(function(error) {
                    miniToastr.error(error.message, "Failure")
                });
            },

            getTranslatedIfExists() {
                this.saveTempInfo();
                this.loadBlog(this.$route.params.slug, this.blog.locale);
            },

            saveTempInfo() {
                this.temp_blog.loaded = true;
                this.temp_blog.file = this.blog.file;
                this.temp_blog.file_slug = this.blog.file_slug;
                this.temp_blog.category = this.blog.category;
            },

            loadTempInfo() {
                this.blog.file = this.temp_blog.file;
                this.blog.file_slug = this.temp_blog.file_slug;
                this.blog.category = this.temp_blog.category;
                this.temp_blog.loaded = false;
            },
        },
        mounted() {
            const vm = this;
            vm.getCategories();
            Event.$on('media_selection_done', function(event){
                vm.setMedia(event);
            });

            if(vm.$route.params.slug) {
                vm.edit = true;
                vm.loadBlog(vm.$route.params.slug);
            }
        },
    }
</script>
<style scoped>
    .ql-tooltip.ql-editing {
        z-index: 99;
    }

    .row_input {
        //margin-top: 5px;
        margin-bottom: 10px;
    }

    .dz-progress {
        background-color: #08aa80 !important;
    }

    .fa {
        cursor: pointer
    }

    .fa-plus {
        font-size: 100px;
        margin-top: 25px;
    }

    #action_row {
        margin-bottom: 15px;
    }

    .form-danger {
        border: 1px red solid;
    }

    .is-danger {
        color: red;
    }

    .help {
        padding: 10px;
    }
</style>