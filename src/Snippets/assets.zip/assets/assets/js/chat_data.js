let chat = [{
    user: "Rickey",
    image: require("img/authors/avatar2.jpg"),
    status: "Lorem ipsum dolor sit ametm  elit.",
    mbl_num:"9876543210",
    work:"Google",
    messages: [{
        msg: "Hi",
        from: "me",
        time:"09:10"
    }, {
        msg: "Good Morning",
        from: "me",
        time:"09:11"
    }, {
        msg: "Have a Nice day",
        from: "you",
        time:"09:12"
    }, {
        msg: "Hi ,How are you?",
        from: "me",
        time:"09:13"
    }, {
        msg: " Morning",
        from: "you",
        time:"09:14"
    }, {
        msg: "Have a Nice day",
        from: "me",
        time:"09:15"
    }, {
        msg: "Hi ,How are you?",
        from: "You",
        time:"09:16"
    }, {
        msg: "I am Fine",
        from: "me",
        time:"09:17",
    }, {
        msg: "I am Good",
        from: "you",
        time:"09:18"
    }]
}, {
    user: "Jenny",
    image: require("img/authors/avatar4.jpg"),
    status: "Consec  ipsum  adipisicing.Lorem   elit.",
    mbl_num:"8907654231",
    work:"Apple",
    messages: [{
        msg: "Hi,Good Morning",
        from: "me",
        time:"17:23"
    }, {
        msg: "Have a Nice day",
        from: "you",
        time:"17:24"
    }, {
        msg: "Hi ,How are you?",
        from: "me",
        time:"17:25"
    }, {
        msg: " Morning",
        from: "you",
        time:"17:26"
    }, {
        msg: "Have a Nice day",
        from: "me",
        time:"17:27"
    }, {
        msg: "Hi ,How are you?",
        from: "You",
        time:"17:28"
    }, {
        msg: "I am Fine",
        from: "me",
        time:"17:29"
    }, {
        msg: "I am Good",
        from: "you",
        time:"17:30"
    }]
}, {
    user: "David",
    image: require("img/authors/avatar3.jpg"),
    status: "Lorem ipsum dolor ipsum dolor  elit",
    mbl_num:"7894561203",
    work:"Microsoft",
    messages: [{
        msg: "Hi",
        from: "me",
        time:"13:49"
    }, {
        msg: "Hello",
        from: "you",
        time:"13:50"
    }, {
        msg: "What Are You Doing",
        from: "me",
        time:"13:51"
    }, {
        msg: "Hello",
        from: "you",
        time:"13:52"
    }, {
        msg: "What Are You Doing",
        from: "me",
        time:"13:53"
    }, {
        msg: "I am Doing Somework",
        from: "you",
        time:"13:54"
    }, {
        msg: "I am Doing Somework",
        from: "me",
        time:"13:55"
    }]
}, {
    user: "Roysingh",
    image: require("img/authors/avatar5.jpg"),
    status: "Dolor ipsum amet elitLorem ipsum ",
    mbl_num:"9587643210",
    work:"Yahoo",
    messages: [{
        msg: "Hi",
        from: "me",
        time:"19:17"
    }, {
        msg: "Hello",
        from: "you",
        time:"19:18"
    }, {
        msg: "What Are You Doing",
        from: "me",
        time:"19:19"
    }, {
        msg: "I am Doing Somework",
        from: "you",
        time:"19:20"
    }]
},{
    user: "Joe",
    image: require("img/authors/avatar6.jpg"),
    status: "Dolor ipsum amet elitLorem ipsum ",
    mbl_num:"8974613215",
    work:"Amazon",
    messages: [{
        msg: "Hi",
        from: "me",
        time:"19:17"
    }, {
        msg: "Hello",
        from: "you",
        time:"19:18"
    }, {
        msg: "What Are You Doing",
        from: "me",
        time:"19:19"
    }, {
        msg: "I am Doing Somework",
        from: "you",
        time:"19:20"
    }]
}, {
    user: "Shasla",
    image: require("img/authors/avatar.jpg"),
    status: "Dolor ipsum dolor dolor elitLorem ",
    mbl_num:"7598642130",
    work:"IBM",
    messages: [{
        msg: "Hi",
        from: "me",
        time:"22:06"
    }, {
        msg: "Hello",
        from: "you",
        time:"22:07"
    }, {
        msg: "What Are You Doing",
        from: "you",
        time:"22:08"
    }, {
        msg: "I am Doing Somework",
        from: "me",
        time:"22:09"
    }]
}]


export default chat
